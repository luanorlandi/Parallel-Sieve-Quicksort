# OpenMP Eratosthenes Sieve
Project to make the Sieve of Eratosthenes.

The program uses OpenMP, a open library for parallel programming.

## Compile

The project uses OpenMP, a open library for parallel programming. You will need it to compile.

```bash
  $ gcc -g -Wall -fopenmp -o sieve sieve.c -lm
```
